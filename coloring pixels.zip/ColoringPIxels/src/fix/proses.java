/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author ASUS
 */
public class proses extends JPanel {

    //private BufferedImage temp, temp1;
    private int x, y,ex1,ey1,ex2,ey2;
    
    public void proses(int x, int y) {
        this.x=x;
        this.y=y;
        //temp = new BufferedImage(x, y, BufferedImage.TYPE_INT_ARGB);
    }

    @Override
    public void paint(Graphics g) {
        //int x = temp.getWidth();
        //int y = temp.getHeight();
        g.setColor(Color.red);
        g.fillRect(x, y, 2, 2);
    }
    
        
}
