/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author ASUS
 */
public class garis extends JPanel{
    private BufferedImage temp,temp1;
    public garis(double x,double y,double x1,double y1)
{
    temp =new BufferedImage((int)x, (int)y, BufferedImage.TYPE_INT_ARGB);
    temp1 =new BufferedImage((int)x1,(int)y1, BufferedImage.TYPE_INT_ARGB);
}
    @Override
        public void paint(Graphics g)
        {
            //super.paintComponents(g);
            double x=temp.getWidth();
            double y=temp.getHeight();
            double x1=temp1.getWidth();
            double y1=temp1.getHeight();
            double dx,dy,step,xs,ys;
            dx =x1-x;
            dy =y1-y;
            if (Math.abs(dx)>Math.abs(dy)) {
                step = Math.abs(dx);
            }
            else
            {
                step = Math.abs(dy);
            }
            xs=dx/step;
            ys=dy/step;
            
            double ax=x;
            double ay=y;
            //g.fillRect(ax, ay, 1, 1);
            for(int i=0;i<=step;i++)
            {
              ax = (ax + xs);
              ay = (ay+ ys);
              g.setColor(Color.blue);
              g.fillRect((int) ax, (int)ay, 1,1);              
            }
        }
    

}
