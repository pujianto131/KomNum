/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

/**
 *
 * @author ASUS
 */
public class lengkung extends JPanel{
    private BufferedImage temp,temp1,temp2;
    public lengkung(int a,int b,int c)
    {
       temp = new BufferedImage(a, b, BufferedImage.TYPE_INT_ARGB);
       temp1 = new BufferedImage(c, c, BufferedImage.TYPE_INT_ARGB);
    }
    @Override
    public void paint(Graphics g)
    {
        int x =temp.getWidth();
        int y =temp.getHeight();
        int r =temp1.getHeight();
        double p;
        p=1-r;
        while(x<y)
        {
            x++;
            if(p<0)
            {
                p += 2*x+1;
                //System.out.print(p);
            }
            else
            {
                p += 2*(x-y)+1;
                y--;
            }
            g.setColor(Color.red);
            g.fillRect(x, y, 1, 1);
        }
       
    }
    
}
