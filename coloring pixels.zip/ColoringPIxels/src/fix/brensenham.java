/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author ASUS
 */
public class brensenham extends JPanel {

    private BufferedImage temp, temp1;
    private int ex1, ex2, ey1, ey2;

    public brensenham(int x, int y, int x1, int y1) {
        temp = new BufferedImage(x, y, BufferedImage.TYPE_INT_ARGB);
        temp1 = new BufferedImage(x1, y1, BufferedImage.TYPE_INT_ARGB);
    }
    
    @Override
    public void paintComponent(Graphics g) {
        double x = temp.getWidth();
        double y = temp.getHeight();
        double x1 = temp1.getWidth();
        double y1 = temp1.getHeight();
        double dx = (x1 - x), dy = (y1 - y);
        double p = 2 * dy - dx, xEnd, ex, ey;
        double duaDy = 2 * dy, duaDyDx = 2 * (dy - dx);
        if (x > x1) {
            ex = x1;
            ey = y1;
            xEnd = x;
        } else {
            ex = x;
            ey = y;
            xEnd = x1;
        }
        g.setColor(Color.red);
        g.fillRect((int) ex, (int) ey, 2, 2);
        while (ex < xEnd) {
            ex++;
            if (p < 0) {
                p += duaDy;
            } else {
                ey++;
                p += duaDyDx;
            }
            g.setColor(Color.red);
            g.fillRect((int) ex, (int) ey, 2, 2);
        }
    }


}
