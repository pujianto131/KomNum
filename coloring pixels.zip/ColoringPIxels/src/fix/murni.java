/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 *
 * @author ASUS
 */
public class murni extends JPanel {

    private double ex1, ey1, ex2, ey2;

    public void murni(double ex1, double ey1, double ex2, double ey2) {
        this.ex1 = ex1;
        this.ex2 = ex2;
        this.ey1 = ey1;
        this.ey2 = ey2;
    }

    @Override
    public void paint(Graphics g) {


        double ex = ex1, ey=ey1, dy, dx;
        dx = ex2 - ex1;
        dy = ey2 - ey1;

        if (ex > ex2) {
            for (ex = ex1; ex > ex2; ex--) {
                ey = ey1 + dy * (ex - ex1) / dx;
                g.fillRect((int) ex, (int) ey, 1, 1);
            }
        } else {
            for (ex = ex1; ex < ex2; ex++) {
                ey = ey1 + dy * (ex - ex1) / dx;
                g.fillRect((int) ex, (int) ey, 1, 1);
            }
        }


    }
}
