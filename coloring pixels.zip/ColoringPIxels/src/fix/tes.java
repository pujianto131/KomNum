        /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package fix;

import com.sun.org.apache.xalan.internal.xsltc.dom.FilteredStepIterator;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author ASUS
 */
public class tes extends JPanel {

    private double ex1, ey1, ex2, ey2,dx,dy,dx2,dy2;
    float x,y;
    private int p;
    public void bresenham(double ex1, double ey1, double ex2, double ey2) {
        this.ex1 = ex1;
        this.ex2 = ex2;
        this.ey1 = ey1;
        this.ey2 = ey2;
    }

    @Override
    public void paint(Graphics g) {
        x=(float) ex1;y=(float) ey1;
        dx = Math.abs(ex2 - ex1);
        dy = Math.abs(ey2 - ey1); 
        dy2 = (dy + 1);
        dx2 = (dx + 1);
        int ix = x < ex2 ? 1 : -1;
        int iy = y < ey2 ? 1 : -1;

        if (dy <= dx) {
            for (;;) {
                g.setColor(Color.red);
                g.fillRect((int) x, (int) y, 1, 1);
                if (x == ex2) {
                    break;
                }
                x += ix;
                p += dy2;
                if (p > dx) {
                    y += iy;
                    p -= dx2;
                }
            }
        } else {
            for (;;) {
                g.setColor(Color.red);
                g.fillRect((int) x, (int) y, 1, 1);
                if (y == ey2) {
                    break;
                }
                y += iy;
                p += dx2;
                if (p > dy) {
                    x += ix;
                    p -= dy2;
                }
            }
        }
    }
}
